from python_quote import random_python_quote

user_quote = random_python_quote()
print("___Q-User______")
print(user_quote)